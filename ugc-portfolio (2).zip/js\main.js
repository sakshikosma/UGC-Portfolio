/**
 * SAKSHI KOSMA — UGC CREATOR PORTFOLIO
 * Interactive JavaScript Engine
 */

// Portfolio Concept & Spec Registry
const PORTFOLIO_DATA = [
  {
    brand: "CeraVe Skincare Spec",
    title: "Problem vs. Solution Skin Barrier Routine",
    hook: "“The one cleanser mistake that ruined my skin barrier in college.”",
    caption: "Stop scrolling if your skin feels dry and tight after cleansing. Here's why ceramides + squalane transformed my morning routine ✨ #skincareroutine #barrierrepair",
    category: "skincare paidads",
    views: "4K 60fps",
    roas: "1.8s Hook",
    ctr: "Organic",
    likes: "24.5k",
    comments: "812",
    saves: "6.4k",
    videoSrc: "https://assets.mixkit.co/videos/preview/mixkit-woman-applying-moisturizer-on-her-face-41132-large.mp4",
    poster: "https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=600&q=80",
    strategy: "Emotional hook questioning common college cleansing mistakes, transitioning into a soothing texture closeup and natural demonstration of proper barrier repair application.",
    deliverables: [
      "1 Edited 4K Vertical Reel (0:24)",
      "2 Hook variations for testing",
      "Raw B-roll clips & clean voiceover"
    ]
  },
  {
    brand: "Laneige Spec Review",
    title: "Aesthetic ASMR Nighttime Lip Routine",
    hook: "“Nighttime Lip Plumping Routine you need to try before bed.”",
    caption: "The sound of pure hydration 🤍 My non-sticky secret for waking up with plump, nourished lips. Available now at Sephora. #asmrskincare #liproutine #nighttimeroutine",
    category: "skincare",
    views: "4K 60fps",
    roas: "ASMR Audio",
    ctr: "Organic",
    likes: "48k",
    comments: "640",
    saves: "12k",
    videoSrc: "https://assets.mixkit.co/videos/preview/mixkit-girl-applying-lip-gloss-with-brush-41133-large.mp4",
    poster: "https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&w=600&q=80",
    strategy: "Sensory ASMR-driven organic concept crafted with tapping, satisfying uncap sounds, and a dewy morning bed lighting setup.",
    deliverables: [
      "1 Organic TikTok/Reels Video (0:18)",
      "Dedicated ASMR high-gain audio mix",
      "Full Organic Social Usage Rights"
    ]
  },
  {
    brand: "Mejuri Jewelry Spec",
    title: "3 Ways to Elevate Casual Outfits with Minimal Gold",
    hook: "“3 Ways to elevate a simple white tee with waterproof gold pieces.”",
    caption: "Never taking these off — literally showered with zero tarnish. How I layer chunky hoops and chain links ✨ #jewelrystyling #capsulewardrobe",
    category: "fashion",
    views: "4K 60fps",
    roas: "1.5s Hook",
    ctr: "Styling Spec",
    likes: "18k",
    comments: "320",
    saves: "4.8k",
    videoSrc: "https://assets.mixkit.co/videos/preview/mixkit-woman-putting-on-a-necklace-41136-large.mp4",
    poster: "https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?auto=format&fit=crop&w=600&q=80",
    strategy: "Addresses the #1 objection in everyday jewelry (tarnishing) with a live water splash demonstration that builds immediate viewer trust.",
    deliverables: [
      "1 Styling Transition Video (0:31)",
      "2 Alternate opening hook edits",
      "Organic & Paid Usage Rights"
    ]
  },
  {
    brand: "Matcha Wellness Spec",
    title: "Direct Response Concept — Ceremonial Matcha vs. Coffee",
    hook: "“Why I replaced coffee with ceremonial matcha for zero afternoon jitters.”",
    caption: "The 3pm energy crash used to ruin my focus. Switching to first-harvest ceremonial matcha gave me clean sustained calm energy all day 🍵 #matchalover #wellnesshacks",
    category: "paidads lifestyle",
    views: "4K 60fps",
    roas: "2.0s Hook",
    ctr: "Problem/Sol",
    likes: "29k",
    comments: "410",
    saves: "7.2k",
    videoSrc: "https://assets.mixkit.co/videos/preview/mixkit-woman-drinking-hot-tea-in-the-morning-41135-large.mp4",
    poster: "https://images.unsplash.com/photo-1508759073847-9ca702cec7d2?auto=format&fit=crop&w=600&q=80",
    strategy: "Comparative direct-response structure testing relatable morning habits and offering an aesthetically pleasing solution.",
    deliverables: [
      "2 Hook Variations",
      "1 Core Body & 2 CTA options",
      "Spark Ads Code & 30-day License"
    ]
  },
  {
    brand: "Home Lifestyle Spec",
    title: "Aesthetic Sunday Reset: French Flax Linen Unboxing",
    hook: "“Unboxing my dream French flax sheets: Sunday bedroom reset.”",
    caption: "Nothing compares to fresh linen sheets on Sunday afternoon ☁️ Unboxing the Oatmeal Dune set. Feels like a 5-star hotel bed. #sundayreset #neutralhome",
    category: "lifestyle",
    views: "4K 60fps",
    roas: "ASMR Audio",
    ctr: "Unboxing",
    likes: "21k",
    comments: "280",
    saves: "5.4k",
    videoSrc: "https://assets.mixkit.co/videos/preview/mixkit-woman-arranging-pillows-on-a-bed-41138-large.mp4",
    poster: "https://images.unsplash.com/photo-1583847268964-b28dc8f51f92?auto=format&fit=crop&w=600&q=80",
    strategy: "Tapped into the popular 'Sunday Reset' aesthetic with focus on textural fabric close-ups and cozy neutral bedroom lighting.",
    deliverables: [
      "1 Unboxing & Room Styling Video (0:22)",
      "High-res thumbnail stills",
      "Organic Social Usage Rights"
    ]
  },
  {
    brand: "Apparel Capsule Spec",
    title: "Capsule Wardrobe Wool Coat Try-On & Review",
    hook: "“The one tailored wool coat you need for an effortless autumn wardrobe.”",
    caption: "Investment pieces that never go out of style 🍂 Styling this double-breasted coat for classes, coffee runs, and evening dinner. #capsulewardrobe #quietluxury",
    category: "fashion paidads",
    views: "4K 60fps",
    roas: "1.9s Hook",
    ctr: "Try-On",
    likes: "33k",
    comments: "490",
    saves: "8.1k",
    videoSrc: "https://assets.mixkit.co/videos/preview/mixkit-woman-looking-at-herself-in-the-mirror-41137-large.mp4",
    poster: "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=600&q=80",
    strategy: "Demonstrates 3 distinct styling occasions, showing versatility and real-world fit notes for prospective buyers.",
    deliverables: [
      "1 High-Energy Try-on Edit (0:35)",
      "Raw footage B-roll pack",
      "Social Commercial Usage License"
    ]
  },
  {
    brand: "Minimalist Skincare Spec",
    title: "Educational Skin Barrier Serum Breakdown",
    hook: "“Stop pairing active serums with these ingredients. Do this instead.”",
    caption: "Skin barrier 101: Why sandwiching active serums with calming ceramides is the only way to avoid irritation. Save this for your evening routine 🧬 #skincaretips #minimalist",
    category: "skincare paidads",
    views: "4K 60fps",
    roas: "Educational",
    ctr: "Doctor Style",
    likes: "44k",
    comments: "820",
    saves: "15k",
    videoSrc: "https://assets.mixkit.co/videos/preview/mixkit-woman-applying-facial-cream-in-front-of-a-mirror-41134-large.mp4",
    poster: "https://images.unsplash.com/photo-1608248597359-0027f6c6d2fe?auto=format&fit=crop&w=600&q=80",
    strategy: "Educational structure with on-screen ingredient highlights that positions the product as an essential solution.",
    deliverables: [
      "1 Educational Concept Video (0:29)",
      "Text & ingredient overlay animations",
      "Spark Ads Code & 30-day Usage"
    ]
  },
  {
    brand: "Casetify Spec Ad",
    title: "Pattern Interrupt Drop Test: Aesthetic Phone Case",
    hook: "“I dropped my phone down marble stairs so you don’t have to.”",
    caption: "The heart attack was real but the case actually held up 😭 Zero cracks, zero scratches, and it still looks chic. #phonecasedroptest #aestheticvibes",
    category: "lifestyle paidads",
    views: "4K 60fps",
    roas: "0.8s Interrupt",
    ctr: "Viral Hook",
    likes: "92k",
    comments: "1.2k",
    saves: "22k",
    videoSrc: "https://assets.mixkit.co/videos/preview/mixkit-young-woman-taking-photos-with-smartphone-41139-large.mp4",
    poster: "https://images.unsplash.com/photo-1584438784894-089d6a62b8fa?auto=format&fit=crop&w=600&q=80",
    strategy: "Immediate pattern interrupt in opening second. Viral pacing paired with authentic relatable reaction and product proof shot.",
    deliverables: [
      "1 High-Paced Drop Test Ad (0:19)",
      "2 Alternate opening angles",
      "Commercial Rights"
    ]
  }
];

// Active State Tracker
let currentPlayingIndex = 0;
let isAudioMuted = true;

// DOM Initialization
document.addEventListener("DOMContentLoaded", () => {
  initProfileCustomizer();
  initThemeSwitcher();
  initHeaderScroll();
  initMobileMenu();
  initPortfolioFilters();
  initRateCalculator();
  initCopyrightYear();
});

/* ==========================================================================
   LIVE PROFILE CUSTOMIZER (NAME, EMAIL, SOCIALS)
   ========================================================================== */
function initProfileCustomizer() {
  const savedProfile = localStorage.getItem("ugc_creator_profile");
  if (savedProfile) {
    try {
      const data = JSON.parse(savedProfile);
      applyProfileData(data);
    } catch (e) {
      console.error(e);
    }
  }
}

function openProfileCustomizer() {
  const modal = document.getElementById("customizerModal");
  if (modal) {
    // Populate current values
    const currentName = document.getElementById("navCreatorName") ? document.getElementById("navCreatorName").textContent : "Sakshi Kosma";
    const currentEmail = document.getElementById("displayEmail") ? document.getElementById("displayEmail").textContent : "sakshikosma.ugc@gmail.com";
    const currentIg = document.getElementById("displayIgHandle") ? document.getElementById("displayIgHandle").textContent : "@sakshi.ugc";
    const currentTiktok = document.getElementById("displayTiktokHandle") ? document.getElementById("displayTiktokHandle").textContent : "@sakshikosma.ugc";
    const currentLoc = document.getElementById("displayLocation") ? document.getElementById("displayLocation").textContent : "Open for Global & National Shipping";

    if (document.getElementById("inputCustomName")) document.getElementById("inputCustomName").value = currentName;
    if (document.getElementById("inputCustomEmail")) document.getElementById("inputCustomEmail").value = currentEmail;
    if (document.getElementById("inputCustomInstagram")) document.getElementById("inputCustomInstagram").value = currentIg;
    if (document.getElementById("inputCustomTiktok")) document.getElementById("inputCustomTiktok").value = currentTiktok;
    if (document.getElementById("inputCustomLocation")) document.getElementById("inputCustomLocation").value = currentLoc;

    modal.classList.add("active");
    modal.setAttribute("aria-hidden", "false");
    document.body.style.overflow = "hidden";
  }
}

function closeProfileCustomizer() {
  const modal = document.getElementById("customizerModal");
  if (modal) {
    modal.classList.remove("active");
    modal.setAttribute("aria-hidden", "true");
    document.body.style.overflow = "";
  }
}

function saveProfileChanges() {
  const name = document.getElementById("inputCustomName").value.trim() || "Sakshi Kosma";
  const email = document.getElementById("inputCustomEmail").value.trim() || "sakshikosma.ugc@gmail.com";
  const ig = document.getElementById("inputCustomInstagram").value.trim() || "@sakshi.ugc";
  const tiktok = document.getElementById("inputCustomTiktok").value.trim() || "@sakshikosma.ugc";
  const loc = document.getElementById("inputCustomLocation").value.trim() || "Open for Global & National Shipping";

  const profileData = { name, email, ig, tiktok, loc };
  localStorage.setItem("ugc_creator_profile", JSON.stringify(profileData));
  applyProfileData(profileData);

  closeProfileCustomizer();
  showToast(`✨ Profile updated! Welcome, ${name}.`);
}

function applyProfileData(data) {
  const firstName = data.name.split(" ")[0];

  // Document Title
  document.title = `${data.name} | Emerging UGC Creator & Creative Storyteller`;

  // Header & Hero
  if (document.getElementById("navCreatorName")) document.getElementById("navCreatorName").textContent = data.name;
  if (document.getElementById("heroCreatorFirstName")) document.getElementById("heroCreatorFirstName").textContent = firstName;
  if (document.getElementById("heroCreatorCaption")) document.getElementById("heroCreatorCaption").textContent = `${data.name} • UGC Creator`;
  if (document.getElementById("aboutBadgeTitle")) document.getElementById("aboutBadgeTitle").textContent = `${data.name} • UGC Specialist`;

  // Contact & Socials
  if (document.getElementById("displayEmail")) document.getElementById("displayEmail").textContent = data.email;
  if (document.getElementById("displayIgHandle")) document.getElementById("displayIgHandle").textContent = data.ig;
  if (document.getElementById("displayTiktokHandle")) document.getElementById("displayTiktokHandle").textContent = data.tiktok;
  if (document.getElementById("displayLocation")) document.getElementById("displayLocation").textContent = data.loc;
  if (document.getElementById("modalAuthorHandle")) document.getElementById("modalAuthorHandle").textContent = data.ig;

  // Footer & Modals
  if (document.getElementById("footerCreatorName")) document.getElementById("footerCreatorName").textContent = data.name;
  if (document.getElementById("footerCopyrightName")) document.getElementById("footerCopyrightName").textContent = data.name;
  if (document.getElementById("rateCardTitle")) document.getElementById("rateCardTitle").textContent = `${data.name} — UGC Rate Card`;
  if (document.getElementById("mockupCreatorName")) document.getElementById("mockupCreatorName").textContent = data.name.toUpperCase();
}

/* ==========================================================================
   THEME SWITCHER SYSTEM (CHAMPAGNE / ROSE / NOIR)
   ========================================================================== */
function initThemeSwitcher() {
  const themeBtn = document.getElementById("themeBtn");
  const themeMenu = document.getElementById("themeMenu");
  const themeOpts = document.querySelectorAll("[data-set-theme]");
  
  const savedTheme = localStorage.getItem("ugc_portfolio_theme") || "champagne";
  setTheme(savedTheme);

  if (themeBtn && themeMenu) {
    themeBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      themeMenu.classList.toggle("open");
    });

    document.addEventListener("click", (e) => {
      if (!themeMenu.contains(e.target) && !themeBtn.contains(e.target)) {
        themeMenu.classList.remove("open");
      }
    });

    themeOpts.forEach((opt) => {
      opt.addEventListener("click", () => {
        const themeName = opt.getAttribute("data-set-theme");
        setTheme(themeName);
        themeMenu.classList.remove("open");
        showToast(`Aesthetic set to: ${themeName.charAt(0).toUpperCase() + themeName.slice(1)}`);
      });
    });
  }
}

function setTheme(themeName) {
  document.body.setAttribute("data-theme", themeName);
  localStorage.setItem("ugc_portfolio_theme", themeName);

  document.querySelectorAll("[data-set-theme]").forEach((btn) => {
    btn.classList.toggle("active", btn.getAttribute("data-set-theme") === themeName);
  });
}

/* ==========================================================================
   STICKY HEADER & MOBILE MENU
   ========================================================================== */
function initHeaderScroll() {
  const header = document.getElementById("header");
  window.addEventListener("scroll", () => {
    if (window.scrollY > 40) {
      header.style.boxShadow = "var(--shadow-md)";
    } else {
      header.style.boxShadow = "none";
    }
  });
}

function initMobileMenu() {
  const mobileBtn = document.getElementById("mobileMenuBtn");
  const mobileDrawer = document.getElementById("mobileDrawer");
  const mobileLinks = document.querySelectorAll(".mobile-nav-link");

  if (mobileBtn && mobileDrawer) {
    mobileBtn.addEventListener("click", () => {
      const isOpen = mobileDrawer.classList.toggle("open");
      mobileBtn.classList.toggle("open", isOpen);
      mobileBtn.setAttribute("aria-expanded", isOpen);
    });

    mobileLinks.forEach((link) => {
      link.addEventListener("click", () => {
        mobileDrawer.classList.remove("open");
        mobileBtn.classList.remove("open");
        mobileBtn.setAttribute("aria-expanded", "false");
      });
    });
  }
}

/* ==========================================================================
   PORTFOLIO FILTERING
   ========================================================================== */
function initPortfolioFilters() {
  const filterTabs = document.querySelectorAll(".filter-tab");
  const cards = document.querySelectorAll(".ugc-card");

  filterTabs.forEach((tab) => {
    tab.addEventListener("click", () => {
      filterTabs.forEach((t) => {
        t.classList.remove("active");
        t.setAttribute("aria-selected", "false");
      });

      tab.classList.add("active");
      tab.setAttribute("aria-selected", "true");

      const filterValue = tab.getAttribute("data-filter");

      cards.forEach((card) => {
        const categories = card.getAttribute("data-category") || "";
        if (filterValue === "all" || categories.includes(filterValue)) {
          card.style.display = "flex";
          setTimeout(() => {
            card.style.opacity = "1";
            card.style.transform = "translateY(0)";
          }, 10);
        } else {
          card.style.opacity = "0";
          card.style.transform = "translateY(12px)";
          setTimeout(() => {
            card.style.display = "none";
          }, 200);
        }
      });
    });
  });
}

/* ==========================================================================
   INTERACTIVE VIDEO MODAL PLAYER
   ========================================================================== */
function openPortfolioModal(index) {
  if (index < 0 || index >= PORTFOLIO_DATA.length) return;
  currentPlayingIndex = index;
  const data = PORTFOLIO_DATA[index];

  const modal = document.getElementById("videoModal");
  const videoElem = document.getElementById("modalVideoElement");
  const phonePlayBtn = document.getElementById("phonePlayBtn");

  // Populate metadata
  document.getElementById("modalBrandBadge").textContent = data.brand;
  document.getElementById("modalTitle").textContent = data.title;
  document.getElementById("modalHookQuote").textContent = data.hook;
  document.getElementById("modalPhoneCaption").textContent = data.caption;
  document.getElementById("modalStatViews").textContent = data.views;
  document.getElementById("modalStatRoas").textContent = data.roas;
  document.getElementById("modalStatCtr").textContent = data.ctr;
  document.getElementById("modalReelLikes").textContent = data.likes;
  document.getElementById("modalReelComments").textContent = data.comments;
  document.getElementById("modalReelSaves").textContent = data.saves;
  document.getElementById("modalStrategyText").textContent = data.strategy;

  // Deliverables
  const deliverablesContainer = document.getElementById("modalDeliverables");
  deliverablesContainer.innerHTML = data.deliverables
    .map((item) => `<li><i class="fa-solid fa-check"></i> ${item}</li>`)
    .join("");

  // Video element setup
  if (videoElem) {
    videoElem.src = data.videoSrc;
    videoElem.poster = data.poster;
    videoElem.muted = isAudioMuted;
    
    const playPromise = videoElem.play();
    if (playPromise !== undefined) {
      playPromise
        .then(() => {
          phonePlayBtn.classList.remove("show");
        })
        .catch(() => {
          phonePlayBtn.classList.add("show");
        });
    }
  }

  modal.classList.add("active");
  modal.setAttribute("aria-hidden", "false");
  document.body.style.overflow = "hidden";
}

function closePortfolioModal() {
  const modal = document.getElementById("videoModal");
  const videoElem = document.getElementById("modalVideoElement");
  
  if (videoElem) {
    videoElem.pause();
  }

  modal.classList.remove("active");
  modal.setAttribute("aria-hidden", "true");
  document.body.style.overflow = "";
}

function toggleVideoPlayback() {
  const videoElem = document.getElementById("modalVideoElement");
  const phonePlayBtn = document.getElementById("phonePlayBtn");

  if (!videoElem) return;

  if (videoElem.paused) {
    videoElem.play();
    phonePlayBtn.classList.remove("show");
  } else {
    videoElem.pause();
    phonePlayBtn.classList.add("show");
  }
}

function toggleVideoSound(event) {
  if (event) event.stopPropagation();
  const videoElem = document.getElementById("modalVideoElement");
  const soundIcon = document.getElementById("soundIcon");

  if (!videoElem) return;

  isAudioMuted = !isAudioMuted;
  videoElem.muted = isAudioMuted;

  if (isAudioMuted) {
    soundIcon.className = "fa-solid fa-volume-xmark";
    showToast("Video muted");
  } else {
    soundIcon.className = "fa-solid fa-volume-high";
    showToast("Video sound unmuted");
  }
}

function openFeaturedReel() {
  openPortfolioModal(0);
}

function inquireFromModal() {
  const data = PORTFOLIO_DATA[currentPlayingIndex];
  closePortfolioModal();

  const detailsField = document.getElementById("campaignDetails");
  const campaignTypeField = document.getElementById("campaignType");

  if (campaignTypeField) {
    campaignTypeField.value = "Custom Campaign Quote";
  }

  if (detailsField) {
    detailsField.value = `Hi! I love your "${data.title}" concept for ${data.brand}. We would like to collaborate on a similar concept for our product...`;
  }

  const contactSec = document.getElementById("contact");
  if (contactSec) {
    contactSec.scrollIntoView({ behavior: "smooth" });
    setTimeout(() => {
      document.getElementById("contactName").focus();
    }, 600);
  }
}

document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") {
    closePortfolioModal();
    closeMediaKitModal();
    closeProfileCustomizer();
  }
});

const videoModalBackdrop = document.getElementById("videoModal");
if (videoModalBackdrop) {
  videoModalBackdrop.addEventListener("click", (e) => {
    if (e.target === videoModalBackdrop) {
      closePortfolioModal();
    }
  });
}

const customizerBackdrop = document.getElementById("customizerModal");
if (customizerBackdrop) {
  customizerBackdrop.addEventListener("click", (e) => {
    if (e.target === customizerBackdrop) {
      closeProfileCustomizer();
    }
  });
}

/* ==========================================================================
   INTERACTIVE RATES & STARTER ESTIMATOR
   ========================================================================== */
function initRateCalculator() {
  const slider = document.getElementById("videoCountSlider");
  const countVal = document.getElementById("videoCountVal");
  const usageSelect = document.getElementById("usageSelect");
  const extraHooksCheck = document.getElementById("extraHooksCheck");
  const rawFootageCheck = document.getElementById("rawFootageCheck");
  const rushDeliveryCheck = document.getElementById("rushDeliveryCheck");
  const totalDisplay = document.getElementById("calcTotalDisplay");

  if (!slider || !totalDisplay) return;

  function calculateQuote() {
    const videoCount = parseInt(slider.value, 10);
    countVal.textContent = `${videoCount} ${videoCount === 1 ? 'Video' : 'Videos'}`;

    // Starter pricing algorithm for fresher:
    // 1 video: $120 base
    // Additional videos: $80 each
    let base = 120 + (videoCount - 1) * 80;

    // Ad Usage rights
    const usageCost = parseInt(usageSelect.value, 10) || 0;
    base += usageCost;

    // Extra hooks: $30 per video
    if (extraHooksCheck && extraHooksCheck.checked) {
      base += videoCount * 30;
    }

    // Raw footage: $50 flat
    if (rawFootageCheck && rawFootageCheck.checked) {
      base += 50;
    }

    // Rush delivery: $60 flat
    if (rushDeliveryCheck && rushDeliveryCheck.checked) {
      base += 60;
    }

    totalDisplay.textContent = base.toLocaleString();
  }

  slider.addEventListener("input", calculateQuote);
  usageSelect.addEventListener("change", calculateQuote);
  if (extraHooksCheck) extraHooksCheck.addEventListener("change", calculateQuote);
  if (rawFootageCheck) rawFootageCheck.addEventListener("change", calculateQuote);
  if (rushDeliveryCheck) rushDeliveryCheck.addEventListener("change", calculateQuote);

  calculateQuote();
}

function applyCalculatedQuote() {
  const videoCount = document.getElementById("videoCountSlider").value;
  const total = document.getElementById("calcTotalDisplay").textContent;
  const usageText = document.getElementById("usageSelect").options[document.getElementById("usageSelect").selectedIndex].text;

  const campaignTypeField = document.getElementById("campaignType");
  const detailsField = document.getElementById("campaignDetails");

  if (campaignTypeField) {
    campaignTypeField.value = "Custom Campaign Quote";
  }

  if (detailsField) {
    detailsField.value = `Custom Package Request: ${videoCount} Videos (~$${total}). Rights selected: ${usageText}. Looking forward to discussing product shipment and concepts!`;
  }

  const contactSec = document.getElementById("contact");
  if (contactSec) {
    contactSec.scrollIntoView({ behavior: "smooth" });
    setTimeout(() => {
      document.getElementById("contactName").focus();
    }, 600);
  }

  showToast(`Custom quote ($${total}) applied to inquiry form!`);
}

function prefillContactForm(packageName) {
  const campaignTypeField = document.getElementById("campaignType");
  const detailsField = document.getElementById("campaignDetails");

  if (campaignTypeField) {
    campaignTypeField.value = packageName;
  }

  if (detailsField) {
    detailsField.value = `Interested in the ${packageName}. Here are our product details, preferred timeline, and goals...`;
  }

  showToast(`Selected: ${packageName}`);
}

/* ==========================================================================
   MEDIA KIT MODAL & DOWNLOAD SIMULATION
   ========================================================================== */
function openMediaKitModal() {
  const modal = document.getElementById("mediaKitModal");
  if (modal) {
    modal.classList.add("active");
    modal.setAttribute("aria-hidden", "false");
    document.body.style.overflow = "hidden";
  }
}

function closeMediaKitModal() {
  const modal = document.getElementById("mediaKitModal");
  if (modal) {
    modal.classList.remove("active");
    modal.setAttribute("aria-hidden", "true");
    document.body.style.overflow = "";
  }
}

function simulateDownloadKit() {
  const currentName = document.getElementById("navCreatorName") ? document.getElementById("navCreatorName").textContent.replace(/\s+/g, '_') : "Sakshi_Kosma";
  showToast(`Downloading ${currentName}_UGC_RateCard_2026.pdf...`);
  setTimeout(() => {
    closeMediaKitModal();
    showToast("Rate Card downloaded! Check your downloads folder.");
  }, 1200);
}

/* ==========================================================================
   COPY EMAIL TO CLIPBOARD
   ========================================================================== */
function copyEmailToClipboard() {
  const emailElem = document.getElementById("displayEmail");
  const email = emailElem ? emailElem.textContent : "sakshikosma.ugc@gmail.com";

  if (navigator.clipboard && window.isSecureContext) {
    navigator.clipboard.writeText(email).then(() => {
      showToast("Email address copied to clipboard: " + email);
    }).catch(() => {
      fallbackCopyText(email);
    });
  } else {
    fallbackCopyText(email);
  }
}

function fallbackCopyText(text) {
  const textArea = document.createElement("textarea");
  textArea.value = text;
  textArea.style.position = "fixed";
  textArea.style.left = "-999999px";
  document.body.appendChild(textArea);
  textArea.focus();
  textArea.select();
  try {
    document.execCommand('copy');
    showToast("Email address copied to clipboard: " + text);
  } catch (err) {
    showToast("Direct Email: " + text);
  }
  document.body.removeChild(textArea);
}

/* ==========================================================================
   CONTACT FORM VALIDATION & INTERACTIVE SUBMISSION
   ========================================================================== */
function handleFormSubmit(event) {
  event.preventDefault();

  const nameInput = document.getElementById("contactName");
  const brandInput = document.getElementById("contactBrand");
  const emailInput = document.getElementById("contactEmail");
  const websiteInput = document.getElementById("contactWebsite");
  const detailsInput = document.getElementById("campaignDetails");
  const submitBtn = document.getElementById("submitBtn");

  let isValid = true;

  if (!nameInput.value.trim()) {
    setError(nameInput, "nameError", true);
    isValid = false;
  } else {
    setError(nameInput, "nameError", false);
  }

  if (!brandInput.value.trim()) {
    setError(brandInput, "brandError", true);
    isValid = false;
  } else {
    setError(brandInput, "brandError", false);
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(emailInput.value.trim())) {
    setError(emailInput, "emailError", true);
    isValid = false;
  } else {
    setError(emailInput, "emailError", false);
  }

  if (!websiteInput.value.trim()) {
    setError(websiteInput, "websiteError", true);
    isValid = false;
  } else {
    setError(websiteInput, "websiteError", false);
  }

  if (!detailsInput.value.trim()) {
    setError(detailsInput, "detailsError", true);
    isValid = false;
  } else {
    setError(detailsInput, "detailsError", false);
  }

  if (!isValid) return;

  const originalBtnHTML = submitBtn.innerHTML;
  submitBtn.disabled = true;
  submitBtn.innerHTML = `
    <i class="fa-solid fa-spinner fa-spin"></i>
    <span>Transmitting Request...</span>
  `;

  setTimeout(() => {
    submitBtn.innerHTML = `
      <i class="fa-solid fa-check"></i>
      <span>Request Received!</span>
    `;
    submitBtn.style.background = "#27AE60";
    submitBtn.style.borderColor = "#27AE60";

    const creatorName = document.getElementById("navCreatorName") ? document.getElementById("navCreatorName").textContent : "Sakshi";
    showToast(`✨ Thank you! Your collaboration inquiry has been sent to ${creatorName}.`);

    setTimeout(() => {
      submitBtn.disabled = false;
      submitBtn.innerHTML = originalBtnHTML;
      submitBtn.style.background = "";
      submitBtn.style.borderColor = "";
      document.getElementById("ugcInquiryForm").reset();
    }, 3500);

  }, 1200);
}

function setError(inputElement, errorElementId, hasError) {
  const errorElem = document.getElementById(errorElementId);
  if (hasError) {
    inputElement.classList.add("invalid");
    if (errorElem) errorElem.classList.add("show");
  } else {
    inputElement.classList.remove("invalid");
    if (errorElem) errorElem.classList.remove("show");
  }
}

/* ==========================================================================
   TOAST NOTIFICATION HELPER
   ========================================================================== */
let toastTimeout;
function showToast(message) {
  const toast = document.getElementById("toastNotification");
  const msgElem = document.getElementById("toastMsg");

  if (!toast || !msgElem) return;

  msgElem.textContent = message;
  toast.classList.add("active");

  clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => {
    toast.classList.remove("active");
  }, 3400);
}

/* ==========================================================================
   COPYRIGHT YEAR
   ========================================================================== */
function initCopyrightYear() {
  const yearElem = document.getElementById("currentYear");
  if (yearElem) {
    yearElem.textContent = new Date().getFullYear();
  }
}
