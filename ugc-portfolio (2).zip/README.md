# ✨ Sophia Laurent — Luxury UGC Creator Portfolio

A modern, high-converting, feminine luxury portfolio website built specifically for professional **UGC Creators & Creative Strategists**.

Designed with an editorial luxury aesthetic (clean champagne/linen palette, high-fashion serif typography, 9:16 vertical video cards, and direct-response performance metrics).

---

## 🌟 Key Features

* **Editorial Luxury Aesthetic**: Warm champagne and linen tones, delicate borders, elegant typography (`Cormorant Garamond` + `Plus Jakarta Sans`), and plenty of whitespace.
* **Aesthetic Theme Switcher**: Includes 3 curated moods:
  * ✨ *Champagne & Linen* (Warm Neutral Luxury)
  * 🌸 *Soft Rose & Blush* (Romantic Chic Luxury)
  * 🖤 *Noir & Pearl* (High-Fashion Editorial Dark Mode)
* **Strong Hero Section**:
  * Name, "UGC Creator & Storyteller" headline, and core value pitch.
  * Live availability pill (*"Q4 & Q1 Booking Open"*).
  * 4 Key performance metrics (*180+ Videos, 4.4x Avg ROAS, 12M+ Impressions, 48h Turnaround*).
  * Interactive floating 9:16 vertical reel preview with direct case study breakdown.
* **Brand Collaborations Marquee**:
  * Seamless marquee slider featuring luxury and beauty brand aesthetics (*Glossier, Sephora, Gisou, Summer Fridays, Mejuri, Casetify, Kosas, Merit Beauty*).
* **UGC Video Portfolio (9:16 Vertical Video Cards)**:
  * Filter tabs: *All, Skincare & Beauty, Fashion & Jewelry, Wellness & Home, Paid TikTok Ads*.
  * 8 Curated UGC cards with hooks, performance metrics (ROAS, CPA, Views), and tag categories.
  * **Interactive Video Modal Player**: Click any card to launch an authentic iPhone mockup player with working video playback, sound toggle, real-time metrics, hook breakdown, deliverables list, and a 1-click *"Inquire About A Video Like This"* prefill button.
* **Services Offered**:
  * Organic UGC Videos, Direct Response Paid Ads (3 hooks + 2 CTAs), Aesthetic ASMR & Unboxing, High-Res Product Photography, Scripting & Creative Strategy, and Monthly Retainers.
* **Transparent Pricing & Real-Time Package Calculator**:
  * 3 base packages (*Essentials $450*, *Growth Bundle $1,150*, *Scale Retainer $2,600/mo*).
  * **Interactive Rate Estimator**: Clients can drag the slider for video quantity, pick ad usage rights, and toggle add-ons (extra hooks, raw footage, rush delivery) to receive an instant dynamic quote that pre-fills into the inquiry form.
* **Client Testimonials**:
  * Endorsements from verified growth marketers and creative directors with 5-star ratings and ROAS achievements.
* **About Me & Creator Guarantee**:
  * Personal story, audience demographics breakdown (84% female, age 22–35, US/UK/CA), and filming gear specs (iPhone 15 Pro Max 4K 60FPS ProRes, DJI Mic, Godox Studio Lighting).
* **Social Proof Showcase**:
  * Live follower badges for TikTok (`@sophialaurent.ugc`) and Instagram (`@sophia.ugc`), plus aesthetic feed gallery.
* **Working Contact Section**:
  * Availability badge.
  * 1-Click "Copy Email" with instant clipboard confirmation toast.
  * Complete brand inquiry form with validation, package selection, and confirmation state.
  * Instant Media Kit PDF download preview modal.

---

## 🚀 Quick Start (How to Open and Preview)

You can view the website immediately on your computer:

1. **Directly in Browser**: Double-click [`index.html`](file:///C:/Users/ACER/.gemini/antigravity/scratch/ugc-portfolio/index.html) to open it in Chrome, Edge, Safari, or Firefox.
2. **With a Local Server (Recommended for videos)**:
   ```bash
   # Run with Python
   python -m http.server 8000
   
   # Or run with Node
   npx serve .
   ```
   Then open `http://localhost:8000` in your browser.

---

## 🛠️ How to Customize with Your Details

Everything is clearly organized so you can customize your information in minutes:

### 1. Change Your Name and Social Handles
Open [`index.html`](file:///C:/Users/ACER/.gemini/antigravity/scratch/ugc-portfolio/index.html):
* Search for **"Sophia Laurent"** and replace with your name.
* Search for **"@sophia.ugc"** and replace with your Instagram and TikTok handles.
* Search for **"hello@sophialaurent.com"** and replace with your actual email address.

### 2. Update Photos & Video Thumbnails
* In [`index.html`](file:///C:/Users/ACER/.gemini/antigravity/scratch/ugc-portfolio/index.html), look for the `<img>` tags in the hero, about, and portfolio sections.
* You can put your own photos in an `assets/` folder and update the `src` attribute (e.g. `src="assets/my-portrait.jpg"`).

### 3. Add Your Own Videos to the Portfolio
Open [`js/main.js`](file:///C:/Users/ACER/.gemini/antigravity/scratch/ugc-portfolio/js/main.js):
* Look at the `PORTFOLIO_DATA` array at the top of the file.
* Each card has:
  ```javascript
  {
    brand: "Your Brand Name",
    title: "Video Title",
    hook: "“Your hook line”",
    caption: "Caption used in the video...",
    category: "skincare paidads", // categories to filter by
    views: "500K",
    roas: "4.5x",
    videoSrc: "assets/my-video.mp4", // Path to your MP4 or CDN video
    poster: "assets/my-thumbnail.jpg",
    strategy: "Why this video converted...",
    deliverables: ["1 Edited Reel", "3 Hook variations"]
  }
  ```

### 4. Adjust Rates and Packages
* In [`index.html`](file:///C:/Users/ACER/.gemini/antigravity/scratch/ugc-portfolio/index.html), search for `id="pricing"` to update package rates ($450, $1,150, etc.).
* In [`js/main.js`](file:///C:/Users/ACER/.gemini/antigravity/scratch/ugc-portfolio/js/main.js), search for `initRateCalculator()` to customize base pricing and add-on rates in the interactive slider.

### 5. Connect the Contact Form to Receive Emails
Currently, the form runs validation and shows a realistic confirmation state. To receive direct submissions in your inbox:
* **Option A (Free Formspree)**:
  Change `<form id="ugcInquiryForm" ...>` to:
  ```html
  <form action="https://formspree.io/f/YOUR_FORM_ID" method="POST">
  ```
* **Option B (Web3Forms)**:
  Get a free access key at [web3forms.com](https://web3forms.com) and add:
  ```html
  <input type="hidden" name="access_key" value="YOUR_ACCESS_KEY">
  ```

---

## 🌐 Free 1-Click Deployment

You can host this website online for free with your own custom domain:

* **Vercel**: Run `npx vercel` or drag-and-drop the `ugc-portfolio` folder into [vercel.com](https://vercel.com).
* **Netlify**: Drag-and-drop the `ugc-portfolio` folder into [app.netlify.com/drop](https://app.netlify.com/drop).
* **GitHub Pages**: Push this directory to a GitHub repository and turn on GitHub Pages under **Settings &rarr; Pages**.

---

© 2026 Designed for high-converting UGC Creator excellence.
