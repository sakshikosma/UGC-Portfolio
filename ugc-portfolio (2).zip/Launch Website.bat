@echo off
title Opening UGC Creator Portfolio
echo ========================================================
echo   Launching Your UGC Creator Portfolio in Web Browser...
echo ========================================================
echo.

:: Try to launch in Google Chrome or Microsoft Edge directly to prevent MS Office from hijacking .html files
where msedge >nul 2>&1
if %errorlevel% equ 0 (
    echo Opening in Microsoft Edge...
    start msedge "%~dp0index.html"
    exit
)

where chrome >nul 2>&1
if %errorlevel% equ 0 (
    echo Opening in Google Chrome...
    start chrome "%~dp0index.html"
    exit
)

:: Fallback to Windows default browser handler
start "" "%~dp0index.html"
exit
